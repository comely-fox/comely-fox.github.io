const path = require('path')
const fs = require('fs')
const util = require('util')

/**
 *  文件过滤器
 *
 * @param {Function} callback 过滤后合格的文件的回调函数
 * @param {String} filename 需要过滤的文件
 * @param {Object} filter {size: 界限, 文件大小超过后需要过滤, type: 要过滤的文件类型}
 */
exports.filterFile = function (
  callback,
  filename,
  filter = { type: /\.(jpeg|png|gif|jpg|svg)$/, size: 100 /*100kb*/ }
) {
  var ext = path.parse(filename).ext
  var baseSize = fs.statSync(filename).size
  var pattern = util.isRegExp(filter.type)
    ? filter.type
    : new RegExp(filter.type)

  if (pattern.test(ext) && filter.size * 1024 <= baseSize) {
    callback(filename)
  }
}
