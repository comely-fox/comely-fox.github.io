const mkdir = require('./mkdir').mkdirSync
const fs = require('fs')
const path = require('path')

/**
 *  文件移动, 不会影响原始文件, 依赖于mkdir函数
 *
 * @param {Function} from 要移动的文件
 * @param {String} to 文件移动的路径
 */
exports.moveFile = function (from, to) {
  const dir = path.parse(to).dir
  if (!fs.existsSync(dir)) {
    mkdir(dir)
  }
  if (!fs.existsSync(to)) {
    const sourceFile = path.join(__dirname, from)
    const destPath = path.join(__dirname, to)
    const readableStream = fs.createReadStream(sourceFile)
    const writableStream = fs.createWriteStream(destPath)
    readableStream.pipe(writableStream)
  } else {
    console.log("Don't have to move" + '\n-------------')
    return
  }
  console.log(to + '\n' + 'Move to complete' + '\n-------------')
}
