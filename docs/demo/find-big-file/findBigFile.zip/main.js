const readFile = require('./read').readFileSync
const moveFile = require('./move').moveFile
const filterFile = require('./filter').filterFile

const src = 'src' // 要过滤的文件夹
readFile(src, function (url) {
  filterFile(
    (path) => {
      // 过滤成功后的回调
      // 成功后移动文件到新目录下
      console.log(path)
      moveFile(path, './dest/' + path)
    },
    url.path, // 被过滤的文件
    {
      // 过滤的文件类型
      type: /\.(?:jpe?g|png|gif|svg)$/,
      // 指定过滤的文件大小
      size: 3
    }
  )
})
