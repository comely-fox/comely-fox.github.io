const fs = require('fs')

/**
 * 递归的读取某目录下的所有文件, 并采用回调的形式传递
 * @param {String} dir 要搜索的文件目录
 * @param {Function} callback 搜索到的所有文件, 并回调出去
 */
exports.readFileSync = function readFile(dir, callback) {
  const list = fs.readdirSync(dir, callback)
  list.forEach((file) => {
    var path = dir + '/' + file
    const stats = fs.statSync(path)
    stats.isFile()
      ? callback({
          path,
          dir,
          filename: file,
          size: stats.size,
          type: path.slice(path.lastIndexOf('.') + 1)
        })
      : readFile(path, callback)
  })
}
