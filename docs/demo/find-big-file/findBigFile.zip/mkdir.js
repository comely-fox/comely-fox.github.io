const fs = require('fs')
const path = require('path')
/**
 * 递归的创建需要的文件目录
 * @param {String} dir 文件路径
 */
exports.mkdirSync = function mkdir(dir) {
  const pathInfo = path.parse(dir)
  if (!fs.existsSync(pathInfo.dir)) {
    mkdir(pathInfo.dir)
  }
  fs.mkdirSync(pathInfo.dir + '/' + pathInfo.base)
}
